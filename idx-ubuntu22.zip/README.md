# idx-ubuntu22-gui
GUI for Project IDX Google
